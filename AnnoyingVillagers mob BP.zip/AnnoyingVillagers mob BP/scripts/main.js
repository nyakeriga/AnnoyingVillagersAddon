import { system, world, ItemComponentTypes, ItemStack } 
from "@minecraft/server";

import "./flfl.js"