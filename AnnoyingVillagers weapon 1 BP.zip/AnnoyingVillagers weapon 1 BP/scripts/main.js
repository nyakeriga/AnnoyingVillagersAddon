import { system, world, ItemComponentTypes, ItemStack } 
from "@minecraft/server";

import "./guarddddddd.js";
import "./eyegolem.js";
import "./obsidian.js";
import "./spweapens.js";
import "./element.js";
import "./sweep1.js";
import "./sweep2.js";
import "./sweep3.js";
import "./sweep4.js";
import "./sweep5.js";
import "./sweep6.js";
import "./sweep7.js";
import "./sweep8.js";
import "./sweep9.js";
import "./sweep10.js";
import "./sweep11.js";
import "./dpdpp.js";
import "./swordsound.js";
import "./axesound.js";
import "./special.js";
import "./axeguard.js";
import "./armoreffect.js"