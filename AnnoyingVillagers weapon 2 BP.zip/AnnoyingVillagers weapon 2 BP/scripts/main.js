import { system, world, ItemComponentTypes, ItemStack } 
from "@minecraft/server";

import "./fire.js";
import "./flflfl.js";
import "./armor.js";
import "./guard.js";
import "./all.js"